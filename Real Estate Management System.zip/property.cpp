#include <iostream>
#include<string.h>
#include "property.h"

using std::cout;
using std::endl;

namespace example
{
	void property::display(char prop_name[100],string prop_type, int prop_id, int price)
	{
		cout << "Name of the " << prop_type << ": " << prop_name << endl;
		cout << "ID of the " << prop_type << ": " << prop_id << endl;
		cout << "Price of the " << prop_type << ": Rs." << price << endl;
	}
}
