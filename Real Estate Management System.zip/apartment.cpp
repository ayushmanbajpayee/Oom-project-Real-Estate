#include <iostream>
#include <string.h>
#include"property.h"
#include"apartment.h"

using std::cin;
using std::cout;
using std::endl;

namespace example
{
	void apartment::input_apartment()
	{
		cout << "Enter the name of the apartment";
		cin>>prop_name;
		cout << endl;
		cout << "Enter the ID of the apartment";
		cin >> prop_id;
		cout << endl;
		cout << "Enter the number of apartments you want to buy: ";
		cin >> apart_number;
		cout << endl;		
	}
}
