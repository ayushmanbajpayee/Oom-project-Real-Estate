#ifndef __deluxe_apartment
#define __deluxe_apartment

#include "apartment.h"

namespace example
{
	class deluxe_apartment: public apartment
	{
		public:
				deluxe_apartment();
	};
}
#endif