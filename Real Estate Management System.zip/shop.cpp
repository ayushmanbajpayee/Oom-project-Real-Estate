#include <iostream>
#include<string.h>
#include "property.h"
#include "shop.h"

using std::cin;
using std::cout;
using std::endl;

namespace example
{
	void shop::input_shop()
	{
		cout << "Enter the name of the shop: ";
		cin>>prop_name;
		cout << endl;
		cout << "Enter the shop ID: ";
		cin >> prop_id;
		cout << endl;
		cout << "Enter the dimensions of the shop: ";
		cin >> shopdimension1 >> shopdimension2;
		cout << endl;
		price = shopdimension1*shopdimension2*5000;
		display(prop_name, "Shop", prop_id, price);
	}
}
