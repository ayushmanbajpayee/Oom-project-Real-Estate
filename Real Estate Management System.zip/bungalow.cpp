#include <iostream>
#include <string.h>
#include "property.h"
#include "bungalow.h"

using std::cin;
using std::cout;
using std::endl;

namespace example
{
	void bungalow::input_bungalow()
	{
		price = 7500000;
		cout << "Enter the name of the bungalow: ";
		cin>>prop_name;
		cout << endl;
		cout << "Enter the ID of Bungalow: ";
		cin >> prop_id;
		cout << endl;
		display(prop_name, "Bungalow", prop_id, price);
	}
}
