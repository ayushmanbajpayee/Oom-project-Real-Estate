#ifndef __single_apartment
#define __single_apartment

#include <string.h>
#include "apartment.h"

namespace example
{
	class single_apartment: public apartment
	{
		public:
				single_apartment();
	};
}
#endif