#ifndef __property
#define __property

#include <string.h>
using std::string;

namespace example
{
	class property
	{
		public:
				char prop_name[100];
				string prop_type;
				int prop_id;
				int price;
				void display(char*,string, int, int);
	};
}
#endif
