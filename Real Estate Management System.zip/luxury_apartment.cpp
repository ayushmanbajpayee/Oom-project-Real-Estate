#include <iostream>
#include <string.h>
#include "property.h"
#include "apartment.h"
#include "luxury_apartment.h"

using std::cin;
using std::cout;
using std::endl;

namespace example
{
	luxury_apartment::luxury_apartment()
	{
		input_apartment();
		price = 6500000 *apart_number;
		display(prop_name, "Luxury Apartment", prop_id, price);
	}
}

