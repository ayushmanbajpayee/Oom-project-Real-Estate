#ifndef __apartment
#define __apartment

#include "property.h"

namespace example
{
	class apartment: public property
	{
		public:
				int apart_number;
				void input_apartment();
	};
}
#endif