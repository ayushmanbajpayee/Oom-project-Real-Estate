#ifndef __luxury_apartment
#define __luxury_apartment

#include "apartment.h"

namespace example
{
	class luxury_apartment: public apartment
	{
		public:
				luxury_apartment();
	};
}
#endif