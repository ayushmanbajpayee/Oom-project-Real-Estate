#ifndef __land
#define __land

#include "property.h"

namespace example
{
	class land: public property
	{
		private:
				int landdimension1;
				int landdimension2;
		public:
				void input_land();
	};
}
#endif