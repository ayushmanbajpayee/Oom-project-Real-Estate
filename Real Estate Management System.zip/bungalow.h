#ifndef __bungalow
#define __bungalow

#include "property.h"

namespace example
{
	class bungalow: public property
	{
		public:
				void input_bungalow();
	};
}
#endif