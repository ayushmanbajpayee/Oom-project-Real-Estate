#ifndef __shop
#define __shop

#include "property.h"

namespace example
{
	class shop: public property
	{
		private:
				int shopdimension1;
				int shopdimension2;
		public:
				void input_shop();
	};
}
#endif